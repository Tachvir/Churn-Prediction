"""
preprocess.py
-------------
Data cleaning and feature engineering for the Telco Churn dataset.
"""

import pandas as pd
import numpy as np


def load_data(filepath: str) -> pd.DataFrame:
    """Load raw CSV and return a DataFrame."""
    df = pd.read_csv(filepath)
    print(f"Loaded {len(df):,} rows and {df.shape[1]} columns.")
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean raw dataframe:
    - Fix TotalCharges dtype (loaded as string due to whitespace)
    - Drop rows with missing values
    - Drop customerID (not a feature)
    - Encode binary target
    """
    df = df.copy()

    # Fix TotalCharges — contains whitespace for new customers with 0 tenure
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    n_missing = df["TotalCharges"].isna().sum()
    print(f"Dropping {n_missing} rows with missing TotalCharges.")
    df.dropna(subset=["TotalCharges"], inplace=True)

    # Drop ID column — not a feature
    df.drop("customerID", axis=1, inplace=True)

    # Encode target: Yes → 1, No → 0
    df["Churn"] = (df["Churn"] == "Yes").astype(int)
    print(f"Churn rate: {df['Churn'].mean():.1%}")

    return df.reset_index(drop=True)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create new features that improve model performance:
    - tenure_group: bucket tenure into interpretable bands
    - charges_per_month: normalized spend signal
    - has_online_services: binary flag for value-added services
    - num_services: count of subscribed services
    """
    df = df.copy()

    # Tenure bands — captures non-linear relationship with churn
    df["tenure_group"] = pd.cut(
        df["tenure"],
        bins=[0, 12, 24, 48, 72],
        labels=["0-1yr", "1-2yr", "2-4yr", "4-6yr"],
        include_lowest=True,
    )

    # Average monthly spend (smooths out contract-length differences)
    df["charges_per_month"] = df["TotalCharges"] / (df["tenure"] + 1)

    # Whether the customer has protective/support services
    df["has_online_services"] = (
        (df["OnlineSecurity"] == "Yes") | (df["TechSupport"] == "Yes")
    ).astype(int)

    # Total number of additional services subscribed
    service_cols = [
        "PhoneService", "MultipleLines", "OnlineSecurity", "OnlineBackup",
        "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies",
    ]
    df["num_services"] = df[service_cols].apply(
        lambda row: (row == "Yes").sum(), axis=1
    )

    print(f"Feature engineering complete. Shape: {df.shape}")
    return df


def get_feature_lists(df: pd.DataFrame):
    """Return (numerical_features, categorical_features) lists."""
    numerical_features = [
        "tenure",
        "MonthlyCharges",
        "TotalCharges",
        "charges_per_month",
        "num_services",
    ]
    categorical_features = [
        "Contract",
        "PaymentMethod",
        "InternetService",
        "tenure_group",
        "gender",
        "SeniorCitizen",
        "Partner",
        "Dependents",
        "PaperlessBilling",
        "has_online_services",
    ]
    return numerical_features, categorical_features


def prepare_data(filepath: str):
    """
    Full preprocessing pipeline. Returns X, y ready for modeling.

    Usage:
        X, y, num_features, cat_features = prepare_data('data/WA_Fn-UseC_-Telco-Customer-Churn.csv')
    """
    df = load_data(filepath)
    df = clean_data(df)
    df = engineer_features(df)

    num_features, cat_features = get_feature_lists(df)

    feature_cols = num_features + cat_features
    X = df[feature_cols]
    y = df["Churn"]

    return X, y, num_features, cat_features
