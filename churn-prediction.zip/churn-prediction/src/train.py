"""
train.py
--------
Train and evaluate churn prediction models.
Saves the best model to outputs/model.pkl.

Usage:
    python src/train.py
"""

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    ConfusionMatrixDisplay,
)

from preprocess import prepare_data


# ─── Config ────────────────────────────────────────────────────────────────────
DATA_PATH = "data/WA_Fn-UseC_-Telco-Customer-Churn.csv"
MODEL_OUTPUT = "outputs/model.pkl"
RANDOM_STATE = 42
TEST_SIZE = 0.2


# ─── Build sklearn pipeline ────────────────────────────────────────────────────
def build_pipeline(num_features, cat_features, classifier):
    """Wrap preprocessor + classifier into a single sklearn Pipeline."""
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), num_features),
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat_features),
        ]
    )
    return Pipeline(steps=[("preprocessor", preprocessor), ("classifier", classifier)])


# ─── Evaluation helpers ────────────────────────────────────────────────────────
def evaluate(pipeline, X_test, y_test, model_name="Model"):
    """Print classification report and return AUC score."""
    y_pred = pipeline.predict(X_test)
    y_prob = pipeline.predict_proba(X_test)[:, 1]

    print(f"\n{'─'*50}")
    print(f"  {model_name}")
    print(f"{'─'*50}")
    print(classification_report(y_test, y_pred, target_names=["Retained", "Churned"]))

    auc = roc_auc_score(y_test, y_prob)
    print(f"  AUC-ROC: {auc:.4f}")
    return auc, y_pred, y_prob


def plot_confusion_matrix(y_test, y_pred, model_name, save_path=None):
    fig, ax = plt.subplots(figsize=(5, 4))
    cm = confusion_matrix(y_test, y_pred)
    disp = ConfusionMatrixDisplay(cm, display_labels=["Retained", "Churned"])
    disp.plot(ax=ax, colorbar=False, cmap="Blues")
    ax.set_title(f"Confusion Matrix — {model_name}")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved: {save_path}")
    plt.show()


def plot_roc_curves(results, y_test, save_path=None):
    """Plot ROC curves for multiple models."""
    plt.figure(figsize=(7, 5))
    colors = ["#185FA5", "#993C1D", "#888780"]
    for i, (name, y_prob) in enumerate(results):
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        auc = roc_auc_score(y_test, y_prob)
        plt.plot(fpr, tpr, color=colors[i], lw=2, label=f"{name} (AUC = {auc:.2f})")
    plt.plot([0, 1], [0, 1], "k--", lw=1, label="Random baseline")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve Comparison")
    plt.legend(loc="lower right")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved: {save_path}")
    plt.show()


def plot_feature_importance(rf_pipeline, num_features, cat_features, save_path=None):
    """Plot top 15 feature importances from the Random Forest."""
    ohe = rf_pipeline.named_steps["preprocessor"].named_transformers_["cat"]
    cat_encoded = list(ohe.get_feature_names_out(cat_features))
    all_features = num_features + cat_encoded

    importances = rf_pipeline.named_steps["classifier"].feature_importances_
    feat_df = (
        pd.DataFrame({"feature": all_features, "importance": importances})
        .sort_values("importance", ascending=False)
        .head(15)
    )

    plt.figure(figsize=(8, 5))
    sns.barplot(data=feat_df, y="feature", x="importance", color="#185FA5")
    plt.title("Top 15 Feature Importances — Random Forest")
    plt.xlabel("Mean decrease in impurity")
    plt.ylabel("")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved: {save_path}")
    plt.show()


# ─── Main ──────────────────────────────────────────────────────────────────────
def main():
    os.makedirs("outputs", exist_ok=True)
    os.makedirs("images", exist_ok=True)

    # 1. Load & preprocess data
    print("Loading data...")
    X, y, num_features, cat_features = prepare_data(DATA_PATH)

    # 2. Train/test split — stratified to preserve class balance
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, stratify=y, random_state=RANDOM_STATE
    )
    print(f"\nTrain: {len(X_train):,} samples | Test: {len(X_test):,} samples")

    # 3. Define models
    models = {
        "Random Forest": RandomForestClassifier(
            n_estimators=200,
            max_depth=10,
            min_samples_leaf=5,
            class_weight="balanced",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ),
        "Logistic Regression": LogisticRegression(
            C=1.0,
            max_iter=1000,
            class_weight="balanced",
            random_state=RANDOM_STATE,
        ),
    }

    # 4. Train, evaluate, collect ROC data
    roc_results = []
    best_auc = 0
    best_pipeline = None
    best_name = ""

    for name, clf in models.items():
        pipeline = build_pipeline(num_features, cat_features, clf)
        pipeline.fit(X_train, y_train)

        # Cross-validation
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
        cv_scores = cross_val_score(pipeline, X_train, y_train, cv=cv, scoring="roc_auc")
        print(f"\n[{name}] CV AUC: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")

        auc, y_pred, y_prob = evaluate(pipeline, X_test, y_test, name)
        roc_results.append((name, y_prob))

        if auc > best_auc:
            best_auc = auc
            best_pipeline = pipeline
            best_name = name
            best_y_pred = y_pred

    # 5. Save best model
    joblib.dump(best_pipeline, MODEL_OUTPUT)
    print(f"\nBest model: {best_name} (AUC = {best_auc:.4f})")
    print(f"Model saved to: {MODEL_OUTPUT}")

    # 6. Plots
    plot_confusion_matrix(y_test, best_y_pred, best_name, save_path="images/confusion_matrix.png")
    plot_roc_curves(roc_results, y_test, save_path="images/roc_curves.png")

    if best_name == "Random Forest":
        plot_feature_importance(best_pipeline, num_features, cat_features,
                                save_path="images/feature_importance.png")


if __name__ == "__main__":
    main()
