"""
predict.py
----------
Load the trained model and predict churn probability on new customer data.

Usage:
    python src/predict.py --input data/new_customers.csv
    python src/predict.py --input data/new_customers.csv --threshold 0.4
"""

import argparse
import joblib
import pandas as pd

from preprocess import clean_data, engineer_features, get_feature_lists


MODEL_PATH = "outputs/model.pkl"


def load_model(model_path: str = MODEL_PATH):
    """Load the saved pipeline from disk."""
    try:
        model = joblib.load(model_path)
        print(f"Model loaded from: {model_path}")
        return model
    except FileNotFoundError:
        raise FileNotFoundError(
            f"No model found at '{model_path}'. Run `python src/train.py` first."
        )


def predict_churn(model, df_raw: pd.DataFrame, threshold: float = 0.5) -> pd.DataFrame:
    """
    Run predictions on raw customer data.

    Returns a DataFrame with:
        - churn_probability: model confidence score (0–1)
        - churn_prediction: binary label at the given threshold
        - risk_level: human-readable risk band
    """
    # Preprocess
    df = clean_data(df_raw)
    df = engineer_features(df)

    num_features, cat_features = get_feature_lists(df)
    feature_cols = num_features + cat_features
    X = df[feature_cols]

    # Predict
    proba = model.predict_proba(X)[:, 1]
    pred = (proba >= threshold).astype(int)

    # Risk bands
    def risk_band(p):
        if p >= 0.7:
            return "High"
        elif p >= 0.4:
            return "Medium"
        else:
            return "Low"

    results = df_raw.copy()
    results["churn_probability"] = proba.round(4)
    results["churn_prediction"] = pred
    results["risk_level"] = [risk_band(p) for p in proba]

    return results.sort_values("churn_probability", ascending=False)


def main():
    parser = argparse.ArgumentParser(description="Predict customer churn.")
    parser.add_argument("--input", type=str, required=True, help="Path to input CSV")
    parser.add_argument("--threshold", type=float, default=0.5,
                        help="Decision threshold (default: 0.5)")
    parser.add_argument("--output", type=str, default="outputs/predictions.csv",
                        help="Where to save predictions (default: outputs/predictions.csv)")
    args = parser.parse_args()

    model = load_model()
    df_raw = pd.read_csv(args.input)
    print(f"Loaded {len(df_raw):,} customers from {args.input}")

    results = predict_churn(model, df_raw, threshold=args.threshold)

    results.to_csv(args.output, index=False)
    print(f"\nPredictions saved to: {args.output}")

    # Summary
    print("\n── Churn risk summary ──────────────────────")
    print(results["risk_level"].value_counts().to_string())
    print(f"\nAverage churn probability: {results['churn_probability'].mean():.2%}")
    print(f"\nTop 5 highest-risk customers:")
    print(results[["customerID", "churn_probability", "risk_level"]].head(5).to_string(index=False))


if __name__ == "__main__":
    main()
