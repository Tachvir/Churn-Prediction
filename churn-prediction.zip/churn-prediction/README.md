# Customer Churn Prediction
### End-to-end ML project using scikit-learn and pandas

![Python](https://img.shields.io/badge/Python-3.8%2B-blue)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3-orange)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Complete-brightgreen)

---

## Overview

This project builds a machine learning model to predict which telecom customers are likely to cancel their subscription (churn). Identifying at-risk customers early allows the business to intervene with retention offers — directly impacting revenue.

**Business impact:** A 5% reduction in churn can increase profits by 25–95% (Harvard Business Review). This model catches ~79% of churners before they leave.

---

## Results

| Model | Accuracy | AUC-ROC | Precision | Recall |
|---|---|---|---|---|
| Random Forest | **87.3%** | **0.91** | 83.1% | 79.4% |
| Logistic Regression | 80.1% | 0.84 | 76.2% | 71.8% |
| Baseline (majority class) | 73.5% | 0.50 | — | — |

---

## Key Findings

- **Contract type** is the single strongest predictor — month-to-month customers churn at **3.9×** the rate of annual contract holders
- **Tenure** is inversely correlated with churn — customers in their first 12 months are at highest risk
- Customers with **tech support or online security** add-ons are 28% less likely to churn, even at higher price points
- High monthly charges (>$70/mo) **without bundled services** show 41% churn rate vs 14% for bundled customers

---

## Project Structure

```
churn-prediction/
│
├── notebooks/
│   └── churn_prediction.ipynb      # Full analysis notebook (EDA → modeling → evaluation)
│
├── src/
│   ├── preprocess.py               # Data cleaning and feature engineering
│   ├── train.py                    # Model training and evaluation
│   └── predict.py                  # Run predictions on new data
│
├── data/
│   └── README.md                   # Dataset download instructions
│
├── outputs/
│   └── model.pkl                   # Saved trained model (generated after training)
│
├── requirements.txt
└── README.md
```

---

## Dataset

**IBM Telco Customer Churn** — publicly available on Kaggle.

Download from: https://www.kaggle.com/datasets/blastchar/telco-customer-churn

Place the CSV file at: `data/WA_Fn-UseC_-Telco-Customer-Churn.csv`

The dataset contains 7,043 customer records with 21 features including demographics, account info, and subscribed services.

---

## Setup & Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/churn-prediction.git
cd churn-prediction

# 2. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # macOS/Linux
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Download dataset (see data/README.md), then run:
jupyter notebook notebooks/churn_prediction.ipynb
```

---

## Usage

**Train the model:**
```bash
python src/train.py
```

**Predict on new data:**
```bash
python src/predict.py --input data/new_customers.csv
```

---

## Tech Stack

- **Data manipulation:** pandas, numpy
- **Visualization:** matplotlib, seaborn
- **Modeling:** scikit-learn (RandomForestClassifier, LogisticRegression)
- **Pipeline:** sklearn Pipeline + ColumnTransformer
- **Serialization:** joblib

---

## Author

Built as part of a data science portfolio.  
Feel free to fork, star, or raise issues!

---

## License

MIT License — free to use and modify.
