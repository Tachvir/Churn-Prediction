# Data

## Download Instructions

This project uses the **IBM Telco Customer Churn** dataset, publicly available on Kaggle.

### Steps

1. Go to: https://www.kaggle.com/datasets/blastchar/telco-customer-churn
2. Click **Download** (requires a free Kaggle account)
3. Extract the ZIP and place the CSV here:

```
data/WA_Fn-UseC_-Telco-Customer-Churn.csv
```

## Dataset Overview

| Property | Value |
|---|---|
| Rows | 7,043 customers |
| Columns | 21 features |
| Target | `Churn` (Yes / No) |
| Class balance | ~73.5% retained, ~26.5% churned |

## Features

**Demographics**
- `gender`, `SeniorCitizen`, `Partner`, `Dependents`

**Account info**
- `tenure` (months), `Contract`, `PaperlessBilling`, `PaymentMethod`
- `MonthlyCharges`, `TotalCharges`

**Services subscribed**
- `PhoneService`, `MultipleLines`, `InternetService`
- `OnlineSecurity`, `OnlineBackup`, `DeviceProtection`
- `TechSupport`, `StreamingTV`, `StreamingMovies`
